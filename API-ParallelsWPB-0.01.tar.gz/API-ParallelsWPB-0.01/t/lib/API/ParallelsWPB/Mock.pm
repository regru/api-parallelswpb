package API::ParallelsWPB::Mock;
use strict;
use warnings;

use base 'API::ParallelsWPB';

# ABSTRACT: mock for testing API::ParallelsWPB

# VERSION
# AUTHORITY


1;